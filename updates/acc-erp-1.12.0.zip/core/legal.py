"""The ACC's terms, refund & cancellation policy and privacy policy are published on the sales site (Arabic + English);
the customer ticks that he read them before paying online, and the order keeps the version he agreed to."""
TERMS_VERSION = "1.0"
SITE = "https://acc-erp.pages.dev"
LINKS = [("الشروط والأحكام", f"{SITE}/terms/"), ("سياسة الاسترجاع والإلغاء", f"{SITE}/refund/"), ("سياسة الخصوصية", f"{SITE}/privacy/")]
