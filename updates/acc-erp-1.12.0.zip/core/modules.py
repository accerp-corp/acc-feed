"""ACC ERP: which parts of the program a client bought (pricing plan + extra modules), chosen by the developer at setup."""

# key: (Arabic name, short description, URL prefixes it opens)
MODULES = {
    "pos": ("نقطة البيع والكاشير", "شاشة البيع، الباركود، الطابعة الحرارية، الورديات وتقفيل اليوم", ("/pos/", "/ui/shop/close")),
    "items": ("الأصناف والمخزن", "الأصناف والأسعار والرصيد، جرد المخزن والتسوية، التالف والهالك", ("/ui/shop/items",)),
    "purchases": ("المشتريات والموردين", "فواتير شراء كاش أو آجل أو جزء وجزء، وحسابات الموردين", ("/ui/shop/purchases",)),
    "partners": ("العملاء الآجل", "البيع الآجل وحد المديونية وكشف حساب العميل", ("/ui/shop/partners",)),
    "money": ("المصروفات والمرتبات وصاحب المحل", "مصاريف تشغيل، أجور وسلف، مسحوبات وإيداعات، سداد موردين", ("/ui/shop/money",)),
    "treasury": ("الخزينة والمحافظ والبنك", "سندات القبض والصرف وأرصدة الخزن", ("/ui/vouchers",)),
    "stores": ("أكتر من مخزن وتحويلات", "المخزن الرئيسي والتشغيلي والتحويل بينهم", ("=/ui/moves/", "/ui/moves/new")),  # «=» exact page; opening stock/count and viewing an invoice stay open
    "returns": ("مرتجع المشتريات للمورد", "رجّع بضاعة للمورد وتنزل من حسابه", ("/ui/shop/returns",)),
    "promos": ("العروض والخصومات", "خصم نسبة/مبلغ، اشتري واحصل، سعر جملة", ("/ui/shop/promos",)),
    "units": ("الوحدات (كرتونة/علبة)", "أكتر من وحدة للصنف بباركود وسعر", ("/ui/shop/units",)),
    "labels": ("ملصقات الباركود والميزان", "طباعة ملصقات وقراءة باركود الميزان", ("/ui/shop/labels",)),
    "expiry": ("الصلاحية (الإنتاج والانتهاء)", "تنبيه بالأصناف اللي قربت تخلص عشان تتباع الأول", ("/ui/shop/expiry",)),
    "valuation": ("تقييم المخزون", "قيمة المخزن بالتكلفة وبسعر البيع", ("/ui/shop/valuation",)),
    "production": ("التصنيع", "تحويل خامات لأصناف تانية بالتكلفة", ("/ui/shop/production",)),
    "recipes": ("المنيو والمكونات", "أصناف المنيو ومكونات كل صنف، التكلفة بسعر آخر فاتورة شراء، وخصم الخامات من المخزن مع كل أوردر", ("/ui/shop/recipes",)),
    "gaming": ("صالة الألعاب بالساعة", "بلايستيشن/بلياردو: فتح جهاز بالساعة وطلبات على نفس الفاتورة", ("/ui/play",)),
    "clinic": ("العيادة", "ملف المريض والزيارات، الحجز والدور، الروشتة، أكتر من دكتور بنسبة، والمستهلكات بتتخصم من المخزن مع كل زيارة",
               ("/ui/clinic",)),
    "branches": ("أكتر من فرع", "كل فرع بمخزنه وخزينته ومديره، وصاحب النشاط يشوف الفروع كلها وتقاريرها", ("/ui/shop/branches",)),
    "profit_monthly": ("تقرير الأرباح الشهري والشركاء", "ربح الشهر، نصيب كل شريك، وربحكم فين: مسحوبات، نقدية، بضاعة",
                       ("=/ui/shop/profit/", "/ui/shop/profit/partners")),
    "profit_yearly": ("تقرير الأرباح السنوي", "السنة كلها شهر بشهر ونصيب كل شريك في السنة", ("/ui/shop/profit/year",)),
    "report_whatsapp": ("ملخص اليوم على واتساب", "زرار في تقفيل اليوم يبعت الملخص لواتساب صاحب المحل", ()),
    "report_telegram": ("ملخص اليوم على تليجرام", "بيتبعت تلقائي آخر اليوم على بوت تليجرام", ()),
    "report_email": ("ملخص اليوم على الإيميل", "بيتبعت تلقائي آخر اليوم على إيميل صاحب المحل", ()),
    "drive_backup": ("نسخة احتياطية على جوجل درايف", "نسخة أونلاين بجانب النسخة المحلية", ()),
    "mobile": ("تابع محلك من الموبايل", "لينك على موبايلك بأيقونة ACC ERP: مبيعات النهارده والخزنة والنواقص وآخر الفواتير — بيتحدّث كل 10 دقايق", ()),
}

PLANS = {
    "basic": ("أساسي", ["pos", "items", "purchases", "partners", "money", "treasury", "profit_monthly", "expiry"]),
    "standard": ("متقدم", ["pos", "items", "purchases", "partners", "money", "treasury", "profit_monthly", "stores", "returns", "promos", "units", "labels",
                           "expiry", "valuation"]),
    "pro": ("شامل", list(MODULES)),
}

# what each business type gets on top of the plan (it is what the business is about)
BUSINESS = {
    "market": ("سوبر ماركت / بقالة", ["labels", "units"]),
    "retail": ("محل تجزئة (ملابس، أدوات، موبايلات…)", []),
    "cafe": ("كافيه / مطعم", ["recipes"]),
    "gaming": ("بلايستيشن / بلياردو + كافيه", ["gaming", "recipes"]),
    "clinic": ("عيادة / مركز طبي", ["clinic"]),
}

ALWAYS = ("pos", "items", "profit_monthly", "expiry")
LATER = ("mobile",)  # parts added after copies were set up with an explicit list

# parts that only make sense for some business types: a clothes shop never sees the gaming hall or manufacturing,
# whatever the plan says (the «شامل» plan included)
FOR_BUSINESS = {
    "gaming": ("gaming",),
    "recipes": ("cafe", "gaming"),
    "production": ("market",),  # cafés / restaurants work with the menu (recipes) instead
    "clinic": ("clinic",),
    # a clinic has no barcode labels, pack units or shop promotions
    "labels": ("market", "retail", "cafe", "gaming"),
    "units": ("market", "retail", "cafe", "gaming"),
    "promos": ("market", "retail", "cafe", "gaming"),
}


def fits(key, business):
    return business in FOR_BUSINESS.get(key, (business,))


def enabled(settings_obj=None):
    """The set of open modules. An empty list (copies set up before modules existed) means the plan's defaults."""
    from .models import CompanySettings

    s = settings_obj or CompanySettings.get()
    business = getattr(s, "business", "") or "market"
    plan = getattr(s, "plan", "pro") or "pro"
    mods = set(s.modules) if s.modules else set(defaults(plan, business))
    if plan == "pro" and s.modules:  # a full «شامل» saved before a part existed gets the new part too
        full = {m for m in PLANS["pro"][1] if m not in LATER and fits(m, business)}
        if full <= mods:
            mods |= set(LATER)
    return {m for m in mods | set(ALWAYS) if m in MODULES and fits(m, business)}


def defaults(plan, business):
    mods = set(PLANS.get(plan, PLANS["pro"])[1]) | set(BUSINESS.get(business, ("", []))[1]) | set(ALWAYS)
    return sorted((m for m in mods if fits(m, business)), key=list(MODULES).index)


def module_for_path(path):
    for key, (_, _, prefixes) in MODULES.items():
        for pre in prefixes:
            if (path == pre[1:]) if pre.startswith("=") else path.startswith(pre):
                return key
    return None


# prices shown on the owner's «ترقية وطلبات» page (same as the quote) — EGP, once
PLAN_PRICES = {"basic": 10000, "standard": 15000, "pro": 20000}
ADDON_PRICES = {"production": 1500, "profit_yearly": 1000, "branches": 3000, "report_whatsapp": 500,
                "report_telegram": 750, "report_email": 750, "drive_backup": 1000, "stores": 1000, "returns": 1000, "promos": 1000,
                "units": 1000, "labels": 1000, "valuation": 1000, "mobile": 1500}
SERVICES = [("cashier", "جهاز كاشير إضافي", 1500), ("custom", "تعديل أو ميزة خاصة", 2000),
            ("support", "زيارة / دعم فني", 600), ("renew", "تجديد الاشتراك السنوي", 1500),
            ("lifetime", "رخصة مدى الحياة (من غير تجديد سنوي)", 15000), ("lifetime_updates", "التحديثات مدى الحياة (أي إصدار جديد يوصلك لوحده)", 10000)]
