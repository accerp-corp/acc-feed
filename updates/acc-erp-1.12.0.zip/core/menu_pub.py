"""«منيو QR» for cafés / restaurants: the menu (items with their prices, by category) is published to the ACC's Worker and
customers open it by scanning a QR on the table: <Worker>/menu/<public id>. The public id is derived from the shop's secret
(CompanySettings.mobile_key) so the menu link never reveals the owner's phone page. Updated by itself when prices change."""
import hashlib
import json
import time
from pathlib import Path

from django.conf import settings

from . import mobile
from .models import CompanySettings

RAW = ("خامات", "مستلزمات تشغيل")  # ingredients / packing are not on the menu


def on(s=None):
    from .modules import enabled

    return "recipes" in enabled(s or CompanySettings.get())


def public_id(s=None):
    """The same id the Worker computes: sha256("acc-menu:" + key)[:10 bytes] in hex."""
    return hashlib.sha256(("acc-menu:" + mobile.key(s)).encode()).hexdigest()[:20]


def link(s=None):
    base = mobile.api()
    return f"{base}/menu/{public_id(s)}" if base else ""


def hidden(s=None):
    s = s or CompanySettings.get()
    return set((s.menu_cfg or {}).get("hide", []))


def categories():
    from inventory.models import ItemCategory

    return [c for c in ItemCategory.objects.order_by("id") if not any(r in c.name for r in RAW) and c.name != "خدمات"]


def data(s=None):
    from inventory.models import Item

    s = s or CompanySettings.get()
    hide = hidden(s)
    cats = []
    for c in categories():
        if c.pk in hide:
            continue
        items = Item.objects.filter(category=c, active=True, sale_price__isnull=False, sale_price__gt=0).exclude(code="0").order_by("name")
        rows = [dict(n=i.name[:80], p=float(i.sale_price), d=str((i.extra or {}).get("desc", ""))[:120]) for i in items[:150]]
        if rows:
            cats.append(dict(n=c.name[:40], items=rows))
    cfg = s.menu_cfg or {}
    return dict(name=s.name[:80], phone=s.phone[:40], address=s.address[:120], note=str(cfg.get("note", ""))[:200], cats=cats,
                vat=bool(s.default_vat_rate and not s.pos_prices_include_vat))


def _mark_file():
    return Path(settings.BASE_DIR) / "data" / "menu-sent.json"


def push(force=False):
    """Sends the menu when it changed (cheap to call every few minutes). Returns a short status."""
    s = CompanySettings.get()
    if not on(s) or s.suspended:
        return "off"
    if not mobile.api():
        return "no-api"
    d = data(s)
    h = hashlib.sha256(json.dumps(d, sort_keys=True, ensure_ascii=False).encode()).hexdigest()[:16]
    f = _mark_file()
    try:
        mark = json.loads(f.read_text(encoding="utf-8"))
    except Exception:  # noqa: BLE001
        mark = {}
    if not force and mark.get("h") == h:
        return "same"
    res = mobile.post("/menu", dict(mobile.ident(s), d=d))
    if res.get("error"):
        raise ConnectionError(res["error"])
    f.parent.mkdir(exist_ok=True)
    f.write_text(json.dumps(dict(h=h, t=time.time(), id=res.get("id", ""))), encoding="utf-8")
    return "sent"


def last_sent():
    try:
        return json.loads(_mark_file().read_text(encoding="utf-8")).get("t")
    except Exception:  # noqa: BLE001
        return None
