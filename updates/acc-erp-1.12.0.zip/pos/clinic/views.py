from decimal import Decimal, InvalidOperation

from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.core.exceptions import PermissionDenied, ValidationError
from django.db.models import Q
from django.http import JsonResponse
from django.shortcuts import get_object_or_404, redirect, render
from django.utils import timezone

from core.models import CompanySettings
from inventory.models import Item
from pos import voids as V
from treasury.models import CashBox

from . import services as C
from .models import Appointment, Doctor, Patient, Service, Visit

STAFF = ["مدير المحل", "كاشير", "دكتور", "استقبال"]


def _ok(u):
    return u.is_superuser or u.groups.filter(name__in=STAFF).exists()


def guard(view):
    @login_required
    def wrap(request, *a, **k):
        if not _ok(request.user):
            raise PermissionDenied("الصفحة دي لفريق العيادة")
        return view(request, *a, **k)

    wrap.__name__ = view.__name__
    return wrap


def _owner(request):
    if not V.is_owner(request.user):
        raise PermissionDenied("الصفحة دي لصاحب العيادة")


def _errs(request, e):
    for m in getattr(e, "messages", [str(e)]):
        messages.error(request, m)


def _dec(x, default=None):
    try:
        return Decimal(str(x).replace("٫", ".").replace(",", ".").strip()) if str(x or "").strip() else default
    except InvalidOperation:
        raise ValidationError(f"رقم غلط: {x}")


def _doctor(pk):
    return Doctor.objects.filter(pk=pk or 0).first()


def _service(pk):
    return Service.objects.filter(pk=pk or 0).select_related("item", "doctor").first()


def _patient_from(request):
    """The patient picked in a form (id) or a new one typed in (name + phone)."""
    p = Patient.objects.filter(pk=request.POST.get("patient") or 0).first()
    if p:
        return p
    name = request.POST.get("new_name", "").strip()
    if not name:
        raise ValidationError("اختار المريض أو اكتب اسم مريض جديد")
    phone = request.POST.get("new_phone", "").strip()
    same = Patient.objects.filter(name=name, phone=phone).first() if phone else None
    return same or C.add_patient(name, phone)


def _pay_from(request):
    """The «اتدفع دلوقتي» part of a booking / walk-in form: {} when it is paid later at the visit."""
    if not request.POST.get("pay_now"):
        return {}
    pay = request.POST.get("pay", "cash")
    out = dict(pay=pay, discount=_dec(request.POST.get("discount"), Decimal(0)))
    if pay == "split":
        out.update(paid_card=_dec(request.POST.get("card"), Decimal(0)), paid_credit=_dec(request.POST.get("credit"), Decimal(0)))
    return out


def _paid_redirect(appt):
    """After a paid booking: straight to its receipt (it prints itself)."""
    if appt.visit_id and appt.visit.live_payments:
        return redirect(f"/ui/clinic/visits/{appt.visit_id}/receipt/?auto=1")
    return None


def _ctx(**kw):
    return dict(doctors=Doctor.objects.filter(active=True), services=Service.objects.filter(item__active=True).select_related("item", "doctor"),
                today=timezone.localdate(), **kw)


# ---------------------------------------------------------------- today
@guard
def home(request):
    if request.method == "POST":
        a = request.POST.get("action")
        try:
            if a == "walkin":
                appt = C.walk_in(_patient_from(request), doctor=_doctor(request.POST.get("doctor")),
                                 service=_service(request.POST.get("service")), user=request.user, **_pay_from(request))
                messages.success(request, f"{appt.patient.name} دخل الدور — رقم {appt.queue_no}")
                r = _paid_redirect(appt)
                if r:
                    return r
            elif a == "arrive":
                appt = C.arrive(get_object_or_404(Appointment, pk=request.POST["appt"]), request.user)
                messages.success(request, f"{appt.patient.name} وصل — دوره {appt.queue_no}")
            elif a in ("inside", "noshow", "cancelled", "waiting"):
                appt = get_object_or_404(Appointment, pk=request.POST["appt"])
                C.set_state(appt, a, request.user, request.POST.get("reason", ""))
                if a == "inside" and appt.visit_id:
                    return redirect("clinic_visit", appt.visit_id)
        except ValidationError as e:
            _errs(request, e)
        return redirect("clinic_home")
    day = timezone.localdate()
    appts = list(Appointment.objects.filter(date=day).select_related("patient", "doctor", "service__item", "visit"))
    lanes = {k: [a for a in appts if a.state == k] for k in ("booked", "waiting", "inside", "done")}
    owner = V.is_owner(request.user)
    return render(request, "clinic/home.html", _ctx(lanes=lanes, sum=C.today_summary(day) if owner else None, owner=owner,
                                                    others=[a for a in appts if a.state in ("cancelled", "noshow")],
                                                    upcoming=Appointment.objects.filter(date__gt=day, state="booked").count(),
                                                    follow=Visit.objects.filter(next_visit=day).exclude(state="cancelled").select_related("patient")[:20]))


# ---------------------------------------------------------------- bookings
@guard
def appointments(request):
    day = C.parse_date(request.GET.get("d"))
    if request.method == "POST" and request.POST.get("appt"):  # cancel a booking from the list (a paid one is refunded)
        try:
            appt = get_object_or_404(Appointment, pk=request.POST["appt"])
            C.set_state(appt, "cancelled", request.user, request.POST.get("reason", ""))
            messages.success(request, f"اتلغى حجز {appt.patient.name}")
        except ValidationError as e:
            _errs(request, e)
        return redirect(f"{request.path}?d={day.isoformat()}")
    if request.method == "POST":
        try:
            day = C.parse_date(request.POST.get("date"), day)
            t = request.POST.get("time") or None
            appt = C.book(_patient_from(request), day, doctor=_doctor(request.POST.get("doctor")), service=_service(request.POST.get("service")),
                          time=t, note=request.POST.get("note", ""), user=request.user, **_pay_from(request))
            messages.success(request, f"اتحجز {appt.patient.name} يوم {day:%d/%m} — رقم {appt.queue_no}")
            r = _paid_redirect(appt)
            if r:
                return r
        except ValidationError as e:
            _errs(request, e)
        return redirect(f"{request.path}?d={day.isoformat()}")
    import datetime as dt

    days = [day + dt.timedelta(days=i) for i in range(-1, 6)]
    return render(request, "clinic/appointments.html", _ctx(
        day=day, days=days, appts=Appointment.objects.filter(date=day).select_related("patient", "doctor", "service__item", "visit"),
        counts={d: Appointment.objects.filter(date=d).exclude(state__in=["cancelled"]).count() for d in days},
        pick=Patient.objects.filter(pk=request.GET.get("p") or 0).first()))


# ---------------------------------------------------------------- patients
@guard
def patient_find(request):
    q = (request.GET.get("q") or "").strip()
    qs = Patient.objects.filter(active=True)
    if q:
        f = Q(name__icontains=q) | Q(phone__contains=q)
        if q.isdigit():
            f |= Q(number=int(q))
        qs = qs.filter(f)
    return JsonResponse({"items": [dict(id=p.pk, label=f"{p.name} — {p.phone or 'بدون رقم'} (ملف {p.number})") for p in qs[:20]]})


@guard
def patients(request):
    if request.method == "POST":
        try:
            p = C.add_patient(request.POST.get("name"), request.POST.get("phone"), gender=request.POST.get("gender", ""),
                              birth_year=int(request.POST["birth_year"]) if request.POST.get("birth_year", "").isdigit() else None,
                              address=request.POST.get("address", "")[:200], medical_notes=request.POST.get("medical_notes", ""))
            messages.success(request, f"اتفتح ملف {p.name} — رقم {p.number}")
            return redirect("clinic_patient", p.pk)
        except ValidationError as e:
            _errs(request, e)
        return redirect("clinic_patients")
    q = (request.GET.get("q") or "").strip()
    qs = Patient.objects.filter(active=True)
    if q:
        f = Q(name__icontains=q) | Q(phone__contains=q)
        if q.isdigit():
            f |= Q(number=int(q))
        qs = qs.filter(f)
    return render(request, "clinic/patients.html", _ctx(q=q, patients=qs[:200], total=Patient.objects.filter(active=True).count()))


@guard
def patient(request, pk):
    p = get_object_or_404(Patient, pk=pk)
    if request.method == "POST":
        a = request.POST.get("action")
        try:
            if a == "save":
                p.name = request.POST.get("name", p.name).strip()[:120] or p.name
                p.phone = request.POST.get("phone", "").strip()[:40]
                p.gender = request.POST.get("gender", "")
                p.birth_year = int(request.POST["birth_year"]) if request.POST.get("birth_year", "").isdigit() else None
                p.address = request.POST.get("address", "")[:200]
                p.medical_notes = request.POST.get("medical_notes", "")
                p.save()
                messages.success(request, "اتحفظ ✔")
            elif a == "visit":
                appt = C.walk_in(p, doctor=_doctor(request.POST.get("doctor")), service=_service(request.POST.get("service")), user=request.user)
                return redirect("clinic_visit", appt.visit_id)
        except ValidationError as e:
            _errs(request, e)
        return redirect("clinic_patient", p.pk)
    from pos.services import customer_balance

    return render(request, "clinic/patient.html", _ctx(
        p=p, visits=p.visits.select_related("doctor").prefetch_related("lines__item"),
        appts=p.appointments.filter(date__gte=timezone.localdate()).exclude(state__in=["cancelled", "done"]).select_related("doctor"),
        balance=customer_balance(p.partner) if p.partner_id else 0))


# ---------------------------------------------------------------- visit
@guard
def visit(request, pk):
    v = get_object_or_404(Visit.objects.select_related("patient", "doctor", "order"), pk=pk)
    if request.method == "POST":
        a = request.POST.get("action")
        try:
            if a in ("save", "pay", "add"):
                for f in ("complaint", "diagnosis", "prescription", "notes"):
                    if f in request.POST:
                        setattr(v, f, request.POST[f])
                v.next_visit = C.parse_date(request.POST["next_visit"]) if request.POST.get("next_visit") else None
                if not v.live_payments and "doctor" in request.POST:
                    v.doctor = _doctor(request.POST.get("doctor"))
                v.save()
                if v.state != "cancelled":
                    for ln in v.lines.filter(payment__isnull=True):
                        if request.POST.get(f"drop_{ln.pk}"):
                            ln.delete()
                            continue
                        if f"qty_{ln.pk}" in request.POST:
                            ln.qty = _dec(request.POST[f"qty_{ln.pk}"], ln.qty)
                            ln.price = _dec(request.POST.get(f"price_{ln.pk}"), ln.price)
                            if ln.qty <= 0:
                                ln.delete()
                                continue
                            ln.save()
                    code = request.POST.get("add_code", "").strip()
                    if code:
                        it = Item.objects.filter(Q(code=code) | Q(name=code) | Q(barcode=code), active=True).first()
                        if not it:
                            raise ValidationError(f"مفيش خدمة / صنف «{code}»")
                        C.add_line(v, it, request.POST.get("add_qty") or 1)
                if v.state == "open" and v.live_payments and not v.lines.filter(payment__isnull=True).exists():
                    v.state = "paid"
                    v.save(update_fields=["state"])
                if a == "pay":
                    pay = request.POST.get("pay", "cash")
                    v.refresh_from_db()
                    total = v.unbilled - (_dec(request.POST.get("discount"), Decimal(0)))
                    if pay == "split":
                        card, credit = _dec(request.POST.get("card"), 0), _dec(request.POST.get("credit"), 0)
                    else:
                        card, credit = (total if pay == "card" else 0), (total if pay == "credit" else 0)
                    C.checkout(v, request.user, paid_card=card or 0, paid_credit=credit or 0, discount=request.POST.get("discount") or 0)
                    messages.success(request, f"اتحاسبت الزيارة ✔ — {v.patient.name}")
                    if request.POST.get("print"):
                        return redirect(f"/ui/clinic/visits/{v.pk}/receipt/?auto=1")
                else:
                    messages.success(request, "اتحفظ ✔")
            elif a == "finish":  # the doctor is done: the patient leaves the queue
                if v.unbilled:
                    raise ValidationError("فيه خدمات لسه متحاسبتش — حاسب الأول")
                Appointment.objects.filter(visit=v).update(state="done")
                messages.success(request, f"خلص كشف {v.patient.name} ✔")
                return redirect("clinic_home")
            elif a == "cancel":
                C.cancel_visit(v, request.POST.get("reason", ""), request.user)
                messages.success(request, "اتلغت الزيارة — الفلوس رجعت بقيد عكسي والمستهلكات رجعت المخزن")
            elif a == "reopen":
                C.reopen_visit(v, request.POST.get("reason", ""), request.user)
                messages.success(request, "اتفتح الحساب تاني — عدّل وحاسب من جديد")
        except ValidationError as e:
            _errs(request, e)
        return redirect("clinic_visit", v.pk)
    items = Item.objects.filter(active=True, sale_price__isnull=False).exclude(code="0").order_by("item_type", "name")
    return render(request, "clinic/visit.html", _ctx(
        v=v, lines=v.lines.select_related("item", "payment"), items=items, can_edit=V.can_edit(request.user),
        payments=v.payments.select_related("order"), unbilled=v.unbilled,
        in_queue=Appointment.objects.filter(visit=v, state__in=["waiting", "inside"]).exists(),
        history=v.patient.visits.exclude(pk=v.pk).exclude(state="cancelled").select_related("doctor")[:10]))


@guard
def receipt(request, pk):
    """The thermal receipt of a visit's payment (the booking receipt or a later bill): with the queue number."""
    v = get_object_or_404(Visit.objects.select_related("patient", "doctor"), pk=pk)
    pays = list(v.payments.filter(cancelled=False).select_related("order"))
    pay = next((p for p in pays if str(p.pk) == request.GET.get("p")), pays[-1] if pays else None)
    appt = Appointment.objects.filter(visit=v).first()
    return render(request, "clinic/receipt.html", dict(v=v, s=CompanySettings.get(), hide_nav=True, pay=pay, appt=appt,
                                                       lines=pay.lines.select_related("item") if pay else [], auto=request.GET.get("auto") == "1"))


@guard
def print_rx(request, pk):
    v = get_object_or_404(Visit.objects.select_related("patient", "doctor"), pk=pk)
    return render(request, "clinic/print.html", dict(v=v, s=CompanySettings.get(), hide_nav=True, lines=v.lines.select_related("item"),
                                                     receipt=request.GET.get("bill") == "1"))


# ---------------------------------------------------------------- setup (owner)
@guard
def setup(request):
    _owner(request)
    if request.method == "POST":
        a = request.POST.get("action")
        try:
            if a == "doctor":
                doc = Doctor.objects.filter(pk=request.POST.get("pk") or 0).first() or Doctor()
                doc.name = request.POST.get("name", "").strip()[:100]
                if not doc.name:
                    raise ValidationError("اكتب اسم الدكتور")
                doc.specialty = request.POST.get("specialty", "")[:100]
                doc.phone = request.POST.get("phone", "")[:40]
                doc.share_pct = _dec(request.POST.get("share_pct"), Decimal(0))
                if not (0 <= doc.share_pct <= 100):
                    raise ValidationError("النسبة من 0 لـ 100")
                doc.active = request.POST.get("active", "1") == "1"
                doc.save()
                if doc.partner_id:
                    doc.partner.name = f"د. {doc.name}"
                    doc.partner.save(update_fields=["name"])
                messages.success(request, f"اتحفظ {doc}")
            elif a == "service":
                svc = _service(request.POST.get("pk"))
                cons = []
                for code, q in zip(request.POST.getlist("c_item"), request.POST.getlist("c_qty")):
                    if code.strip():
                        it = Item.objects.filter(Q(code=code.strip()) | Q(name=code.strip()), active=True, item_type="stock").first()
                        if not it:
                            raise ValidationError(f"مفيش صنف مخزن «{code}»")
                        cons.append((it, _dec(q, Decimal(1))))
                svc = C.save_service(request.POST.get("name"), _dec(request.POST.get("price"), Decimal(0)), doctor=_doctor(request.POST.get("doctor")),
                                     share_pct=request.POST.get("share_pct", "").strip() or None, minutes=request.POST.get("minutes") or 15,
                                     consumables=cons, service=svc)
                messages.success(request, f"اتحفظت «{svc.item.name}»")
            elif a == "service_off":
                svc = _service(request.POST.get("pk"))
                if svc:
                    svc.item.active = False
                    svc.item.save(update_fields=["active"])
                    messages.success(request, f"اتشالت «{svc.item.name}» من القايمة")
        except ValidationError as e:
            _errs(request, e)
        return redirect("clinic_setup")
    edit_doc = Doctor.objects.filter(pk=request.GET.get("doc") or 0).first()
    edit_svc = _service(request.GET.get("svc"))
    return render(request, "clinic/setup.html", _ctx(
        all_doctors=Doctor.objects.all(), edit_doc=edit_doc, edit_svc=edit_svc,
        edit_cons=list(edit_svc.item.recipe.lines.select_related("ingredient")) if edit_svc and hasattr(edit_svc.item, "recipe") else [],
        stock_items=Item.objects.filter(active=True, item_type="stock").exclude(code="0").order_by("name")))


@guard
def doctors(request):
    _owner(request)
    import datetime as dt

    today = timezone.localdate()
    d1 = C.parse_date(request.GET.get("from"), today.replace(day=1))
    d2 = C.parse_date(request.GET.get("to"), today)
    if request.method == "POST":
        try:
            doc = get_object_or_404(Doctor, pk=request.POST["doctor"])
            box = get_object_or_404(CashBox, pk=request.POST["box"])
            amt = _dec(request.POST.get("amount"), Decimal(0))
            if amt > C.doctor_balance(doc):
                raise ValidationError(f"المبلغ أكبر من مستحقات {doc} ({C.doctor_balance(doc)})")
            C.pay_doctor(doc, amt, cash_account=box.account, user=request.user, note=request.POST.get("note", ""))
            messages.success(request, f"اتصرف {amt} لـ {doc} من {box.name}")
        except (ValidationError, KeyError) as e:
            _errs(request, e)
        return redirect(f"{request.path}?from={d1}&to={d2}")
    rows = C.shares_report(d1, d2)
    return render(request, "clinic/doctors.html", _ctx(rows=rows, d1=d1, d2=d2, boxes=CashBox.objects.filter(active=True),
                                                       visits=Visit.objects.filter(state="paid", opened_at__date__gte=d1, opened_at__date__lte=d2)
                                                       .select_related("patient", "doctor").order_by("-opened_at")[:300],
                                                       last_month=(today.replace(day=1) - dt.timedelta(days=1))))
