from django.urls import path

from . import views

urlpatterns = [
    path("api/cashier/", views.api_cashier, name="pos_api_cashier"),
    path("", views.app, name="pos_app"),
    path("sw.js", views.sw, name="pos_sw"),
    path("api/catalog/", views.api_catalog),
    path("api/sync/", views.api_sync),
]
