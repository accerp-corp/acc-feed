"""Cancelling movements (owner only) and settling a supplier's balance to zero.

Nothing is deleted: every cancel posts the exact opposite entry (and puts the goods back), so the history stays readable.
"""
from decimal import Decimal

from django.core.exceptions import ValidationError
from django.db import transaction
from django.db.models import Sum
from django.utils import timezone

from core import audit
from inventory.models import Item, StockMove, StockQuant
from inventory.services import INCOMING, OUTGOING
from ledger import services as L
from ledger.models import Account, JournalLine

from .models import CashMove, ChangeRequest, Order

Z = Decimal("0")


def is_owner(user):
    """May approve voids / edits: the owner, or anyone given «اعتماد الإلغاء والتعديل» (a branch manager — for his branch)."""
    if not (user and user.is_authenticated):
        return False
    if user.is_superuser or user.groups.filter(name="مدير المحل").exists():
        return True
    from .branches import can

    return can(user, "approve")


def _need_owner(user):
    if not is_owner(user):
        raise ValidationError("الإلغاء والتصفير من حساب الأونر بس — الكاشير يبعت طلب")


def _q(item, wh):
    q, _ = StockQuant.objects.get_or_create(item=item, warehouse=wh)
    return q


def reverse_stock(move: StockMove, reason, user=None):
    move = StockMove.objects.select_for_update().get(pk=move.pk)
    if move.state != "posted":
        raise ValidationError("الحركة مش مرحّلة أو اتلغت قبل كده")
    for ln in move.lines.select_related("item"):
        item = Item.objects.select_for_update().get(pk=ln.item_id)
        value = ln.value or Z
        if move.kind == "transfer":
            q = _q(item, move.warehouse)
            q.qty += ln.qty
            q.save()
            q2 = _q(item, move.to_warehouse)
            q2.qty -= ln.qty
            q2.save()
            continue
        sign = -1 if move.kind in INCOMING else 1 if move.kind in OUTGOING else 0
        q = _q(item, move.warehouse)
        q.qty += sign * ln.qty
        q.save()
        item.qty_on_hand += sign * ln.qty
        item.stock_value += sign * value
        if item.qty_on_hand == 0:
            item.stock_value = Z
        item.save(update_fields=["qty_on_hand", "stock_value"])
    if move.entry_id and move.entry.state == "posted":
        L.reverse(move.entry, date=timezone.localdate(), reason=reason, user=user)
    move.state = "cancelled"
    move.save(update_fields=["state"])
    audit.log("cancel", move, summary=f"إلغاء {move}: {reason}")
    return move


@transaction.atomic
def void_order(order: Order, reason, user=None):
    _need_owner(user)
    order = Order.objects.select_for_update().get(pk=order.pk)
    if order.cancelled:
        raise ValidationError("الفاتورة ملغية بالفعل")
    if order.entry_id and order.entry.state == "posted":
        L.reverse(order.entry, date=timezone.localdate(), reason=reason, user=user)
    if order.stock_move_id:
        reverse_stock(order.stock_move, reason, user)
    order.cancelled = True
    order.flags = (f"ملغية: {reason}؛ " + order.flags)[:300]
    order.save(update_fields=["cancelled", "flags"])
    return order


@transaction.atomic
def void_cash_move(mv: CashMove, reason, user=None):
    _need_owner(user)
    mv = CashMove.objects.select_for_update().get(pk=mv.pk)
    if mv.cancelled:
        raise ValidationError("الحركة ملغية بالفعل")
    if mv.entry_id and mv.entry.state == "posted":
        L.reverse(mv.entry, date=timezone.localdate(), reason=reason, user=user)
    mv.cancelled = True
    mv.note = (f"ملغية: {reason} — " + mv.note)[:200]
    mv.save(update_fields=["cancelled", "note"])
    audit.log("cancel", mv, summary=f"إلغاء {mv.get_kind_display()} {mv.amount}: {reason}")
    return mv


@transaction.atomic
def void_stock_move(move: StockMove, reason, user=None):
    """Purchase invoice / return / expired / transfer. A cash purchase also cancels its payment."""
    _need_owner(user)
    reverse_stock(move, reason, user)
    from treasury import services as T
    from treasury.models import Voucher

    for v in Voucher.objects.filter(legacy_number=f"PUR-{move.pk}", state="posted"):
        T.cancel_voucher(v, reason, user=user)
    return move


def find_target(target):
    """A cashier's request names an invoice or a drawer movement by its number."""
    return Order.objects.filter(uid=target).first() or CashMove.objects.filter(uid=target).first()


@transaction.atomic
def decide(req: ChangeRequest, approve, user, note=""):
    _need_owner(user)
    req = ChangeRequest.objects.select_for_update().get(pk=req.pk)
    if req.state != "pending":
        raise ValidationError("الطلب ده اتقرر قبل كده")
    if approve:
        obj = find_target(req.target)
        if obj is None:
            raise ValidationError(f"مش لاقي الحركة {req.target} — يمكن لسه موصلتش من جهاز الكاشير")
        reason = f"طلب {req.get_kind_display()} من {req.requested_by}: {req.reason}"
        (void_order if isinstance(obj, Order) else void_cash_move)(obj, reason, user)
    req.state = "approved" if approve else "rejected"
    req.decided_by = user.get_username()
    req.decided_at = timezone.now()
    req.decision_note = (note or ("اتلغت — الكاشير يسجلها من جديد صح" if approve and req.kind == "edit" else ""))[:300]
    req.save()
    return req


def partner_balance(partner, code):
    r = JournalLine.objects.filter(account__code=code, partner=partner, entry__state__in=["posted", "reversed"]).aggregate(
        d=Sum("debit"), c=Sum("credit"))
    return (r["d"] or Z) - (r["c"] or Z)


@transaction.atomic
def zero_partner(partner, code, reason, user=None, date=None):
    """Settle a supplier's (or customer's) balance to zero: what we no longer owe is a gain, what we write off is a loss."""
    _need_owner(user)
    bal = partner_balance(partner, code)
    if not bal:
        raise ValidationError("الرصيد صفر بالفعل")
    acc = Account.objects.get(code=code)
    gain = Account.objects.get(code="4401010101")
    loss = Account.objects.filter(code="3202010125").first() or Account.objects.get(code="3801010102")
    desc = f"تصفير حساب {partner.name}: {reason}"
    if bal < 0:   # credit balance: we owed him → owing cancelled = other income
        lines = [dict(account=acc, debit=-bal, partner=partner), dict(account=gain, credit=-bal)]
    else:         # debit balance: he owes us → written off
        lines = [dict(account=loss, debit=bal), dict(account=acc, credit=bal, partner=partner)]
    entry = L.create_entry("JV", date or timezone.localdate(), desc, [dict(ln, description=desc) for ln in lines],
                           source=f"pos.zero:{partner.pk}", user=user)
    audit.log("zero", partner, summary=f"{desc} ({bal:,.2f})")
    return entry
