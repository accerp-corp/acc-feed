"""Point of sale (constitution XVII). Disabled unless CompanySettings.pos_enabled."""
import secrets

from django.conf import settings
from django.db import models

from inventory.models import Item, StockMove, Warehouse
from ledger.models import DimensionValue, JournalEntry
from treasury.models import CashBox


def _token():
    return secrets.token_urlsafe(24)


class Branch(models.Model):
    code = models.CharField("كود الفرع", max_length=6, unique=True)
    name = models.CharField("اسم الفرع", max_length=100)
    warehouse = models.ForeignKey(Warehouse, on_delete=models.PROTECT, verbose_name="مخزن الفرع")
    cashbox = models.ForeignKey(CashBox, on_delete=models.PROTECT, verbose_name="خزنة الفرع")
    cost_center = models.ForeignKey(DimensionValue, on_delete=models.PROTECT, verbose_name="مركز تكلفة الفرع", limit_choices_to={"dimension__number": 1})
    receipt_footer = models.CharField("تذييل الإيصال", max_length=200, blank=True)
    address = models.CharField("العنوان", max_length=200, blank=True)
    phone = models.CharField("التليفون", max_length=40, blank=True)
    active = models.BooleanField("نشط", default=True)

    class Meta:
        verbose_name = "فرع بيع"
        verbose_name_plural = "فروع البيع"

    def __str__(self):
        return self.name


class Device(models.Model):
    branch = models.ForeignKey(Branch, on_delete=models.PROTECT, related_name="devices", verbose_name="الفرع")
    code = models.CharField("كود الجهاز", max_length=6)
    name = models.CharField("اسم الجهاز", max_length=60)
    token = models.CharField("مفتاح الجهاز", max_length=64, unique=True, default=_token, editable=False)
    active = models.BooleanField("نشط", default=True)
    last_sync = models.DateTimeField("آخر مزامنة", null=True, blank=True)

    class Meta:
        verbose_name = "جهاز كاشير"
        verbose_name_plural = "أجهزة الكاشير"
        unique_together = [("branch", "code")]

    def __str__(self):
        return f"{self.branch.code}-{self.code} {self.name}"


class Shift(models.Model):
    uid = models.CharField(max_length=60, unique=True)
    device = models.ForeignKey(Device, on_delete=models.PROTECT, related_name="shifts")
    cashier = models.CharField("الكاشير", max_length=100)
    verified = models.BooleanField("اتأكد بكلمة السر", default=False)
    opened_at = models.DateTimeField("الفتح")
    opening_float = models.DecimalField("رصيد الفتح", max_digits=14, decimal_places=2, default=0)
    closed_at = models.DateTimeField("القفل", null=True, blank=True)
    counted_cash = models.DecimalField("الجرد عند القفل", max_digits=14, decimal_places=2, null=True, blank=True)
    expected_cash = models.DecimalField("المتوقع", max_digits=14, decimal_places=2, null=True, blank=True)
    difference_entry = models.OneToOneField(JournalEntry, null=True, blank=True, on_delete=models.PROTECT, related_name="+")

    class Meta:
        verbose_name = "وردية"
        verbose_name_plural = "الورديات"
        ordering = ["-opened_at"]


class Order(models.Model):
    uid = models.CharField("المعرف الفريد", max_length=60, unique=True, help_text="الفرع-الجهاز-المسلسل، بيتولد على الجهاز")
    device = models.ForeignKey(Device, on_delete=models.PROTECT, related_name="orders")
    shift = models.ForeignKey(Shift, null=True, blank=True, on_delete=models.PROTECT, related_name="orders")
    created_at_device = models.DateTimeField("وقت البيع على الجهاز")
    received_at = models.DateTimeField("وقت الوصول للسيرفر", auto_now_add=True)
    total = models.DecimalField("الإجمالي", max_digits=14, decimal_places=2)
    vat = models.DecimalField("القيمة المضافة", max_digits=14, decimal_places=2, default=0)
    paid_cash = models.DecimalField("نقدي", max_digits=14, decimal_places=2, default=0)
    paid_card = models.DecimalField("فيزا/محفظة", max_digits=14, decimal_places=2, default=0)
    paid_credit = models.DecimalField("آجل", max_digits=14, decimal_places=2, default=0)
    customer = models.ForeignKey("ledger.Partner", null=True, blank=True, on_delete=models.PROTECT, related_name="+", verbose_name="العميل (آجل)")
    is_return = models.BooleanField("مرتجع", default=False)
    flags = models.CharField("تنبيهات للمراجعة", max_length=300, blank=True)
    cancelled = models.BooleanField("ملغية", default=False)
    shift_seq = models.PositiveIntegerField("رقم الفاتورة في الوردية", null=True, blank=True)
    entry = models.OneToOneField(JournalEntry, null=True, blank=True, on_delete=models.PROTECT, related_name="+")
    stock_move = models.OneToOneField(StockMove, null=True, blank=True, on_delete=models.PROTECT, related_name="+")
    raw = models.JSONField("البيانات كما وصلت", default=dict)

    class Meta:
        verbose_name = "فاتورة بيع (نقطة بيع)"
        verbose_name_plural = "فواتير نقاط البيع"
        ordering = ["-created_at_device"]

    def __str__(self):
        return self.uid


class OrderLine(models.Model):
    order = models.ForeignKey(Order, on_delete=models.CASCADE, related_name="lines")
    item = models.ForeignKey(Item, on_delete=models.PROTECT)
    qty = models.DecimalField(max_digits=14, decimal_places=3)
    price = models.DecimalField(max_digits=14, decimal_places=2)
    discount = models.DecimalField(max_digits=14, decimal_places=2, default=0)


class CashMove(models.Model):
    """Money in/out that is not a sale: owner drawings, running expenses, wages and advances, supplier payments.
    From the cashier drawer (POS, works offline) or from the back office (drawer, wallet, bank or the owner's own pocket)."""

    KINDS = [("drawing", "مسحوبات صاحب المحل"), ("deposit", "إيداع من صاحب المحل"), ("expense", "مصروف تشغيل"),
             ("wage", "أجر / مرتب موظف"), ("advance", "سلفة موظف"), ("supplier", "سداد مورد")]
    uid = models.CharField(max_length=60, unique=True)
    kind = models.CharField("النوع", max_length=10, choices=KINDS)
    date = models.DateField("التاريخ")
    shift = models.ForeignKey(Shift, null=True, blank=True, on_delete=models.PROTECT, related_name="cash_moves")
    from_owner = models.BooleanField("اتدفع من جيب صاحب المحل", default=False)
    cash_effect = models.DecimalField("أثرها على الدرج/الخزينة", max_digits=14, decimal_places=2, default=0)
    amount = models.DecimalField("المبلغ", max_digits=14, decimal_places=2)
    deduct_advance = models.DecimalField("خصم سلفة", max_digits=14, decimal_places=2, default=0)
    deduct_penalty = models.DecimalField("خصم / جزاء", max_digits=14, decimal_places=2, default=0)
    partner = models.ForeignKey("ledger.Partner", null=True, blank=True, on_delete=models.PROTECT, related_name="+", verbose_name="الطرف")
    account = models.ForeignKey("ledger.Account", null=True, blank=True, on_delete=models.PROTECT, related_name="+", verbose_name="بند المصروف")
    note = models.CharField("بيان", max_length=200, blank=True)
    entry = models.ForeignKey(JournalEntry, null=True, blank=True, on_delete=models.PROTECT, related_name="+")
    by = models.CharField("بواسطة", max_length=100, blank=True)
    cancelled = models.BooleanField("ملغية", default=False)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        verbose_name = "حركة نقدية"
        verbose_name_plural = "الحركات النقدية (مسحوبات، مصروفات، أجور، موردين)"
        ordering = ["-date", "-id"]


class ChangeRequest(models.Model):
    """A cashier cannot cancel or change a posted movement: he asks, and the owner approves or rejects."""

    KINDS = [("void", "إلغاء"), ("edit", "تعديل")]
    STATES = [("pending", "مستني الاعتماد"), ("approved", "اتعتمد"), ("rejected", "اترفض")]
    uid = models.CharField(max_length=60, unique=True)
    kind = models.CharField("الطلب", max_length=6, choices=KINDS)
    target = models.CharField("الحركة", max_length=60, help_text="رقم الفاتورة أو الحركة")
    reason = models.CharField("السبب / التعديل المطلوب", max_length=300)
    requested_by = models.CharField("طلبه", max_length=100)
    device = models.ForeignKey(Device, null=True, blank=True, on_delete=models.SET_NULL)
    state = models.CharField("الحالة", max_length=10, choices=STATES, default="pending")
    decided_by = models.CharField("قرار", max_length=100, blank=True)
    decided_at = models.DateTimeField(null=True, blank=True)
    decision_note = models.CharField("ملاحظة الأونر", max_length=300, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        verbose_name = "طلب إلغاء / تعديل"
        verbose_name_plural = "طلبات الإلغاء والتعديل"
        ordering = ["-created_at"]


class Promotion(models.Model):
    """Shop offers, applied by the cashier screen automatically while they are active."""

    KINDS = [("percent", "خصم نسبة %"), ("amount", "خصم مبلغ على الوحدة"), ("bxgy", "اشتري كمية والزيادة هدية"), ("qty_price", "سعر جملة من كمية")]
    name = models.CharField("اسم العرض", max_length=100)
    kind = models.CharField("النوع", max_length=10, choices=KINDS)
    item = models.ForeignKey("inventory.Item", on_delete=models.CASCADE, related_name="promotions", verbose_name="الصنف")
    value = models.DecimalField("القيمة", max_digits=10, decimal_places=2, default=0,
                                help_text="النسبة %، أو الخصم بالجنيه، أو سعر الوحدة للجملة")
    min_qty = models.DecimalField("من كمية", max_digits=10, decimal_places=3, default=1)
    free_qty = models.DecimalField("الهدية", max_digits=10, decimal_places=3, default=0, help_text="لعرض «اشتري 2 والتالت هدية»: من كمية 2 والهدية 1")
    start = models.DateField("من")
    end = models.DateField("لحد")
    active = models.BooleanField("شغال", default=True)

    class Meta:
        verbose_name = "عرض"
        verbose_name_plural = "العروض والخصومات"
        ordering = ["-start"]

    def __str__(self):
        return self.name


class ShopPartner(models.Model):
    """A partner (شريك) in the business and his share of the profit. His drawings are tagged with his ledger Partner."""

    partner = models.OneToOneField("ledger.Partner", on_delete=models.PROTECT, related_name="shop_partner", verbose_name="الشريك")
    share = models.DecimalField("نسبته من الربح %", max_digits=6, decimal_places=2)
    active = models.BooleanField("نشط", default=True)
    order = models.PositiveSmallIntegerField(default=0)

    class Meta:
        verbose_name = "شريك"
        verbose_name_plural = "الشركاء ونسبهم"
        ordering = ["order", "id"]

    def __str__(self):
        return f"{self.partner.name} ({self.share}%)"


class Staff(models.Model):
    """Who a user is in the business: his branch (empty = all branches), his job title, and what he may do."""

    user = models.OneToOneField(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="staff")
    branch = models.ForeignKey(Branch, null=True, blank=True, on_delete=models.SET_NULL, related_name="staff", verbose_name="الفرع")
    role = models.CharField("القالب", max_length=20, default="custom")
    title = models.CharField("المسمى الوظيفي", max_length=60, blank=True)
    caps = models.JSONField("الصلاحيات", default=list, blank=True)
    email = models.CharField("إيميل التقارير", max_length=150, blank=True)
    phone = models.CharField("موبايل / واتساب", max_length=40, blank=True)

    class Meta:
        verbose_name = "موظف"
        verbose_name_plural = "الموظفين والصلاحيات"

    def __str__(self):
        return f"{self.user.get_full_name() or self.user.username} — {self.title}"
