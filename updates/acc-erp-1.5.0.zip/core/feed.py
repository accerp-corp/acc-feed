"""The ACC's command channel: one public file of signed codes that every copy reads hourly — no password on the client.

The licence code carries the channel's address (field «f», put there by ACC-License once the channel is set up), so a copy
is connected the moment its licence is pasted: from the flash drive or downloaded online, the same way. The file holds:
  ACCC  — the forced-stop list (the newest applies),
  ACCM  — the newest order for each machine (plan / parts, and a new licence: renewal, lifetime),
  ACCUP — the newest release with the address of its zip («u»), for the machines that may take it («to»).
Everything is signed with the ACC's private key, so a copy of the file cannot be changed or forged.

A licensed copy that has not reached the channel for OFFLINE_DAYS stops (after a warning) until it is online once — so a
forced stop, a renewal or an update can always reach it.
"""
import datetime as dt
import hashlib
import json
import re
import urllib.request
from pathlib import Path

from django.conf import settings
from django.utils import timezone

from . import license as LIC

OFFLINE_DAYS = 30
WARN_DAYS = 7
CODE_RE = re.compile(r"ACC(?:C|M|UP)\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+")


def _state_file():
    p = Path(settings.BASE_DIR) / "data" / "feed.json"
    p.parent.mkdir(parents=True, exist_ok=True)
    return p


def state():
    p = _state_file()
    try:
        return json.loads(p.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}


def _save(**kw):
    st = state()
    st.update(kw)
    _state_file().write_text(json.dumps(st, ensure_ascii=False), encoding="utf-8")
    return st


def feed_url(s=None):
    from .models import CompanySettings

    s = s or CompanySettings.get()
    try:
        return LIC.parse(s.license_code).get("f", "") if s.license_code else ""
    except ValueError:
        return ""


def _get(url, limit=4 << 20, timeout=25):
    sep = "&" if "?" in url else "?"
    req = urllib.request.Request(f"{url}{sep}t={int(timezone.now().timestamp()) // 300}", headers={"User-Agent": "ACC-ERP"})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return r.read(limit)


def offline(s=None, today=None):
    """None when connected (or no channel in the licence); else dict(days, left, blocked)."""
    if not feed_url(s):
        return None
    st = state()
    if not st.get("since"):  # the channel was just added: the count starts now
        st = _save(since=timezone.now().isoformat())
    last = st.get("ok") or st.get("since")
    try:
        last_day = dt.datetime.fromisoformat(last).date()
    except (TypeError, ValueError):
        return None
    today = today or timezone.localdate()
    days = (today - last_day).days
    left = OFFLINE_DAYS - days
    if left > WARN_DAYS:
        return None
    return dict(days=days, left=left, blocked=left < 0)


def check(s=None, fetch=None):
    """Hourly from the launcher (with the mailbox check). No internet → nothing changes."""
    from . import control, updates
    from .models import CompanySettings

    s = s or CompanySettings.get()
    url = feed_url(s)
    if not url:
        return "مفيش قناة أوامر في الرخصة"
    try:
        raw = fetch(url) if fetch else _get(url)
        text = raw.decode("utf-8", "ignore") if isinstance(raw, bytes) else raw
    except Exception as e:  # noqa: BLE001
        _save(failed=timezone.now().isoformat(), error=type(e).__name__)
        return f"قناة الأوامر: مقدرتش أوصل ({type(e).__name__})"
    codes = CODE_RE.findall(text)  # one code per line
    out = []
    # 1) forced stop / resume
    best = control.newest([c for c in codes if c.startswith("ACCC.")])
    if best:
        out.append("الإيقاف: " + control.apply(best, s))
    # 2) plan / parts / licence for this machine
    me, order = LIC.machine_code(), None
    for c in codes:
        if c.startswith("ACCM."):
            try:
                p = updates.verify(c, "ACCM")
            except ValueError:
                continue
            if p.get("m") == me and (order is None or p["t"] > order["t"]):
                order = p
    if order:
        out.append("الترقيات: " + updates.apply_modules(order, CompanySettings.get()))
    # 3) a newer release meant for this machine
    rel = None
    for c in codes:
        if c.startswith("ACCUP."):
            try:
                p = updates.verify(c, "ACCUP")
            except ValueError:
                continue
            if p.get("u") and updates.newer(p.get("v", "0")) and updates._for_me(p.get("to", "*")) and (rel is None or updates.newer(p["v"], rel["v"])):
                rel = p
    if rel:
        st = updates.state()
        if st["ready"] and not updates.newer(rel["v"], st["ready"]["v"]):
            out.append(f"التحديثات: {st['ready']['v']} جاهز")
        else:
            try:
                data = fetch(rel["u"]) if fetch else _get(rel["u"], limit=200 << 20, timeout=300)
                if isinstance(data, str):
                    data = data.encode()
                updates.stage(rel, data)
                out.append(f"التحديثات: {rel['v']} اتحمّل ✔")
            except Exception as e:  # noqa: BLE001
                out.append(f"التحديثات: مقدرتش أحمّل {rel['v']} ({type(e).__name__})")
    _save(ok=timezone.now().isoformat(), error="")
    s.control_checked = timezone.now()
    s.save(update_fields=["control_checked"])
    return "قناة الأوامر ✔ " + (" — ".join(out) if out else "مفيش جديد")
