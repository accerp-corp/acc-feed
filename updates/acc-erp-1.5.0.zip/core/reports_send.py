"""Daily summary to the shop owner: WhatsApp (a ready message opened by a button), Telegram and e-mail (sent by the program).

The developer turns each channel on for the client at installation (settings → «ملخص اليوم»).
Automatic sending: right after the final day close, or at the set hour if the day was not closed (the launcher checks hourly).
"""
import json
import smtplib
import ssl
import urllib.parse
import urllib.request
from email.message import EmailMessage

from django.utils import timezone

from .models import CompanySettings


def summary_text(day):
    from ui.shop import whatsapp_text

    return whatsapp_text(day)


def send_telegram(s, text):
    if not (s.telegram_token and s.telegram_chat):
        raise ValueError("اكتب توكن البوت ورقم المحادثة")
    for chat in [c.strip() for c in s.telegram_chat.split(",") if c.strip()]:
        data = urllib.parse.urlencode({"chat_id": chat, "text": text}).encode()
        with urllib.request.urlopen(f"https://api.telegram.org/bot{s.telegram_token}/sendMessage", data=data, timeout=20) as r:
            if not json.loads(r.read().decode()).get("ok"):
                raise ValueError("تليجرام رفض الرسالة — اتأكد من التوكن ورقم المحادثة")


def telegram_chats(token):
    """After the owner opens the bot and presses Start, his chat id shows up here."""
    with urllib.request.urlopen(f"https://api.telegram.org/bot{token}/getUpdates", timeout=20) as r:
        res = json.loads(r.read().decode()).get("result", [])
    out = {}
    for u in res:
        ch = (u.get("message") or u.get("my_chat_member") or {}).get("chat") or {}
        if ch.get("id"):
            out[str(ch["id"])] = ch.get("title") or " ".join(x for x in [ch.get("first_name"), ch.get("last_name")] if x) or ch.get("username", "")
    return out


def send_email(s, subject, text):
    if not (s.smtp_user and s.smtp_password and s.email_to):
        raise ValueError("اكتب إيميل الإرسال وكلمة سر التطبيق والإيميل اللي هيستقبل")
    m = EmailMessage()
    m["Subject"], m["From"], m["To"] = subject, s.smtp_user, s.email_to
    m.set_content(text)
    with smtplib.SMTP(s.smtp_host, s.smtp_port, timeout=30) as smtp:
        smtp.starttls(context=ssl.create_default_context())
        smtp.login(s.smtp_user, s.smtp_password)
        smtp.send_message(m)


def send_mail_to(s, to, subject, text):
    """Branch managers' reports: the shop's mailbox if set, otherwise the program's mailbox."""
    if s.smtp_user and s.smtp_password:
        snd = dict(host=s.smtp_host, port=s.smtp_port, user=s.smtp_user, password=s.smtp_password)
    else:
        from .devaccess import sender

        snd = sender()
    if not snd:
        raise ValueError("مفيش إيميل إرسال متجهز")
    from .devaccess import smtp_send

    m = EmailMessage()
    m["Subject"], m["From"], m["To"] = subject, snd["user"], to
    m.set_content(text)
    smtp_send(snd, m)


def _owner_send(s, subject, text, out, label):
    if s.report_telegram:
        try:
            send_telegram(s, text)
            out.append((f"تليجرام — {label}", True, "اتبعت"))
        except Exception as e:  # noqa: BLE001
            out.append((f"تليجرام — {label}", False, str(e)))
    if s.report_email:
        try:
            send_email(s, subject, text)
            out.append((f"إيميل — {label}", True, "اتبعت"))
        except Exception as e:  # noqa: BLE001
            out.append((f"إيميل — {label}", False, str(e)))


def send_branches(day, out):
    """Several branches: each manager gets his branch, the owner gets every branch in detail — daily, and the month / year once it ends."""
    from pos.models import Branch, Staff
    from ui import branches as UB

    s = CompanySettings.get()
    d1, d2, title = UB.period("day", day)
    rows, tot, _ = UB.all_report(d1, d2)
    _owner_send(s, f"تقرير الفروع — {s.name} — {day:%d/%m/%Y}", UB.text(rows, tot, f"تقرير الفروع {title}", s.name), out, "كل الفروع")
    managers = Staff.objects.filter(branch__isnull=False, user__is_active=True).exclude(email="").select_related("branch", "user")
    managers = [m for m in managers if "reports" in m.caps]
    for m in managers:
        r = next((x for x in rows if x["branch"].pk == m.branch_id), None)
        if r:
            try:
                send_mail_to(s, m.email, f"تقرير {m.branch.name} — {day:%d/%m/%Y}", UB.text([r], tot, f"{m.branch.name} — {title}", s.name, single=True))
                out.append((f"إيميل {m.branch.name}", True, "اتبعت"))
            except Exception as e:  # noqa: BLE001
                out.append((f"إيميل {m.branch.name}", False, str(e)))
    # the month / year that just ended
    first = day.replace(day=1)
    if day.day <= 7 and (s.last_month_report is None or s.last_month_report < first):
        prev = first - __import__("datetime").timedelta(days=1)
        p1, p2, ptitle = UB.period("month", prev)
        prow, ptot, _ = UB.all_report(p1, p2)
        _owner_send(s, f"تقرير الفروع الشهري — {ptitle}", UB.text(prow, ptot, f"التقرير الشهري لكل الفروع — {ptitle}", s.name), out, "شهري")
        for m in managers:
            r = next((x for x in prow if x["branch"].pk == m.branch_id), None)
            if r:
                try:
                    send_mail_to(s, m.email, f"التقرير الشهري — {m.branch.name} — {ptitle}", UB.text([r], ptot, f"{m.branch.name} — {ptitle}", s.name, single=True))
                except Exception as e:  # noqa: BLE001
                    out.append((f"شهري {m.branch.name}", False, str(e)))
        s.last_month_report = first
        if day.month == 1 and (s.last_year_report is None or s.last_year_report.year < day.year):
            y1, y2, ytitle = UB.period("year", prev)
            yrow, ytot, _ = UB.all_report(y1, y2)
            _owner_send(s, f"تقرير الفروع السنوي — {ytitle}", UB.text(yrow, ytot, f"التقرير السنوي لكل الفروع — {ytitle}", s.name), out, "سنوي")
            s.last_year_report = day
        s.save(update_fields=["last_month_report", "last_year_report"])


def send_daily(day=None, force=False):
    """Returns a list of (channel, ok, message)."""
    s = CompanySettings.get()
    day = day or timezone.localdate()
    if not force and s.last_report == day:
        return []
    out = []
    from pos.branches import branches_on

    if branches_on():
        send_branches(day, out)
        if any(ok for _, ok, _ in out):
            s.last_report = day
            s.save(update_fields=["last_report"])
        return out
    text = summary_text(day)
    if s.report_telegram:
        try:
            send_telegram(s, text)
            out.append(("تليجرام", True, "اتبعت"))
        except Exception as e:  # noqa: BLE001 — reported to the user as text
            out.append(("تليجرام", False, str(e)))
    if s.report_email:
        try:
            send_email(s, f"ملخص {s.name} — {day:%d/%m/%Y}", text)
            out.append(("إيميل", True, "اتبعت"))
        except Exception as e:  # noqa: BLE001
            out.append(("إيميل", False, str(e)))
    if any(ok for _, ok, _ in out):
        s.last_report = day
        s.save(update_fields=["last_report"])
    return out
