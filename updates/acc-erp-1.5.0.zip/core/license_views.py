from django.contrib import messages
from django.shortcuts import redirect, render

from . import license as LIC
from .models import CompanySettings


def page(request):
    s = CompanySettings.get()
    if request.method == "POST" and request.POST.get("action") == "check":
        from . import feed

        res = feed.check(s)
        (messages.success if "✔" in res else messages.error)(request, res if "✔" in res else "مقدرتش أوصل لـ the ACC — اتأكد إن الجهاز عليه نت وجرّب تاني")
        return redirect("/license/")
    if request.method == "POST":
        code = "".join(request.POST.get("code", "").split())
        try:
            lic = LIC.parse(code)
            if lic.get("m") != LIC.machine_code():
                raise ValueError("كود التفعيل ده متعمل لجهاز تاني")
            s.license_code = code
            s.save(update_fields=["license_code"])
            LIC.parse.cache_clear()
            messages.success(request, "اتفعّل البرنامج ✔ " + ("— مدى الحياة" if lic.get("l") else f"لحد {lic.get('e')}"))
            if s.setup_done and lic.get("p"):
                from . import updates

                plan = updates.apply_licence(lic, s)
                if plan:
                    messages.success(request, f"باقتك دلوقتي «{plan}» بالمميزات اللي اشتركت فيها ✔")
            if lic.get("f"):
                from . import feed

                res = feed.check(s)
                if "✔" in res:
                    messages.success(request, "الجهاز اتوصل بـ the ACC ✔ (التحديثات والترقيات هتوصله لوحدها)")
                else:
                    messages.warning(request, f"الجهاز مش متوصل بالنت دلوقتي — لازم يتوصل خلال {feed.OFFLINE_DAYS} يوم")
            return redirect("/")
        except ValueError as e:
            messages.error(request, str(e))
    from . import feed
    import datetime as dt

    ok = feed.state().get("ok")
    from urllib.parse import quote

    wa = "https://wa.me/201008030459?text=" + quote(f"عايز أشترك في ACC ERP\nالمحل: {s.name}\nكود الجهاز: {LIC.machine_code()}")
    return render(request, "core/license.html", dict(st=LIC.status(s), support=LIC.SUPPORT, hide_nav=True, feed_url=feed.feed_url(s), wa=wa,
                                                     feed_ok=dt.datetime.fromisoformat(ok) if ok else None))
